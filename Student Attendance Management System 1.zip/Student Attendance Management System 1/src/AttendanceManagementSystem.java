import java.time.LocalTime;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;

public class AttendanceManagementSystem {
    static List<User> users = new ArrayList<>();
    static List<Course> courses = new ArrayList<>();
    static List<Request> requests = new ArrayList<>();
    static double minAttendancePercentage = 75.0;
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        // Initialize database
        DataManager.initializeDatabase();
        // Load all data from database
        users = DataManager.loadUsers();
        courses = DataManager.loadCourses(users);
        DataManager.loadSessions(courses);
        DataManager.loadAttendance(courses, users);
        requests = DataManager.loadRequests(users, courses);

        // Ensure default admin exists
        if (users.stream().noneMatch(u -> u instanceof Administrator && u.id.equals("A1"))) {
            users.add(new Administrator("A1", "Admin", "admin@example.com", "1112223333", "admin123"));
            DataManager.saveUsers(users);
        }

        while (true) {
            System.out.println("\nSelect an option:\n1. Login as Student\n2. Login as Teacher\n3. Login as Admin\n4. Exit");
            try {
                int choice = Integer.parseInt(scanner.nextLine().trim());
                User user = null;
                switch (choice) {
                    case 1:
                        user = authenticateStudent();
                        if (user != null) {
                            studentMenu((Student) user);
                        } else {
                            System.out.println("Invalid student login. Please try again.");
                        }
                        break;
                    case 2:
                        user = authenticateTeacher();
                        if (user != null) {
                            teacherMenu(user);
                        } else {
                            System.out.println("Invalid teacher login. Please try again.");
                        }
                        break;
                    case 3:
                        user = authenticateAdmin();
                        if (user != null) {
                            adminMenu((Administrator) user);
                        } else {
                            System.out.println("Invalid admin login. Please try again.");
                        }
                        break;
                    case 4:
                        saveAllData();
                        System.out.println("Exiting program successfully.");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid input. Please enter 1, 2, 3, or 4.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Please enter a numeric value.");
            }
        }
    }

    static void saveAllData() throws Exception {
        DataManager.saveUsers(users);
        if (!courses.isEmpty()) DataManager.saveCourses(courses);
        DataManager.saveSessions(courses);
        DataManager.saveAttendance(courses);
        DataManager.saveRequests(requests);
    }

    static User authenticateStudent() {
        System.out.println("Enter Student ID: ");
        final String id = scanner.nextLine().trim();
        System.out.println("Enter Password: ");
        final String password = scanner.nextLine().trim();
        return users.stream()
                .filter(u -> u instanceof Student && u.id.equals(id) && u.password.equals(password))
                .findFirst()
                .orElse(null);
    }

    static User authenticateTeacher() {
        System.out.println("Enter Teacher ID: ");
        String id = scanner.nextLine().trim();
        System.out.println("Enter Password: ");
        String password = scanner.nextLine().trim();
        return users.stream()
                .filter(u -> u instanceof Teacher && u.id.equals(id) && u.password.equals(password))
                .findFirst()
                .orElse(null);
    }

    static User authenticateAdmin() {
        System.out.println("Enter Admin ID: ");
        String id = scanner.nextLine().trim();
        System.out.println("Enter Password: ");
        String password = scanner.nextLine().trim();
        return users.stream()
                .filter(u -> u instanceof Administrator && u.id.equals(id) && u.password.equals(password))
                .findFirst()
                .orElse(null);
    }

    static void studentMenu(Student student) {
        checkAttendanceNotifications(student);
        while (true) {
            System.out.println("\nStudent Menu:\n1. View Attendance\n2. Request Correction\n3. Update Info\n4. View Request Status\n5. Logout");
            try {
                int choice = Integer.parseInt(scanner.nextLine().trim());
                switch (choice) {
                    case 1:
                        viewAttendance(student);
                        checkAttendanceNotifications(student);
                        break;
                    case 2:
                        requestCorrection(student);
                        DataManager.saveRequests(requests);
                        break;
                    case 3:
                        updatePersonalInfo(student);
                        DataManager.saveUsers(users);
                        break;
                    case 4:
                        viewRequestStatus(student);
                        break;
                    case 5:
                        saveAllData();
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Please enter a numeric value.");
            } catch (Exception e) {
                System.out.println("Error saving data: " + e.getMessage());
            }
        }
    }

    static void teacherMenu(User teacher) {
        while (true) {
            System.out.println("\nTeacher Menu:\n1. Mark Attendance\n2. View Attendance\n3. Modify Attendance\n4. Generate Report\n5. Send Alert\n6. View Registered Students\n7. Logout");
            try {
                int choice = Integer.parseInt(scanner.nextLine().trim());
                switch (choice) {
                    case 1:
                        markAttendance(teacher);
                        DataManager.saveSessions(courses);
                        DataManager.saveAttendance(courses);
                        break;
                    case 2:
                        viewClassAttendance(teacher);
                        break;
                    case 3:
                        modifyAttendance(teacher);
                        DataManager.saveAttendance(courses);
                        break;
                    case 4:
                        generateReport(teacher);
                        break;
                    case 5:
                        sendAlert(teacher);
                        break;
                    case 6:
                        viewRegisteredStudents(teacher);
                        break;
                    case 7:
                        saveAllData();
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Please enter a numeric value.");
            } catch (Exception e) {
                System.out.println("Error saving data: " + e.getMessage());
            }
        }
    }

    static void adminMenu(Administrator admin) {
        while (true) {
            System.out.println("\nAdmin Menu:\n1. Manage Users\n2. View Analytics\n3. Configure Rules\n4. Handle Requests\n5. View Registered Students\n6. Manage Courses\n7. Logout");
            try {
                int choice = Integer.parseInt(scanner.nextLine().trim());
                switch (choice) {
                    case 1:
                        manageUsers();
                        DataManager.saveUsers(users);
                        break;
                    case 2:
                        viewAnalytics();
                        break;
                    case 3:
                        configureRules();
                        break;
                    case 4:
                        handleRequests();
                        DataManager.saveRequests(requests);
                        DataManager.saveAttendance(courses);
                        break;
                    case 5:
                        viewRegisteredStudents(admin);
                        break;
                    case 6:
                        manageCourses();
                        DataManager.saveCourses(courses);
                        break;
                    case 7:
                        saveAllData();
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Please enter a numeric value.");
            } catch (Exception e) {
                System.out.println("Error saving data: " + e.getMessage());
            }
        }
    }

    static void viewAttendance(Student student) {
        boolean hasRecords = false;
        for (Course c : courses) {
            if (c.students.contains(student)) {
                System.out.println("Course: " + c.courseName + ", Section: " + student.classSection);
                for (Session s : c.sessions) {
                    for (AttendanceRecord ar : s.attendanceRecords) {
                        if (ar.student.equals(student)) {
                            hasRecords = true;
                            System.out.printf("Date: %s, Status: %s, Check-in: %s, Check-out: %s, Remarks: %s%n",
                                    s.date, ar.status,
                                    ar.checkInTime != null ? ar.checkInTime : "N/A",
                                    ar.checkOutTime != null ? ar.checkOutTime : "N/A",
                                    ar.remarks != null ? ar.remarks : "None");
                        }
                    }
                }
            }
        }
        if (!hasRecords) {
            System.out.println("No attendance records available.");
        }
    }

    static void viewClassAttendance(User teacher) {
        System.out.println("Enter Course ID: ");
        final String courseId = scanner.nextLine().trim();
        Course course = courses.stream()
                .filter(c -> c.courseId.equals(courseId) && (c.teacher != null && c.teacher.equals(teacher)))
                .findFirst()
                .orElse(null);
        if (course == null) {
            System.out.println("Invalid Course ID or you are not assigned to this course.");
            return;
        }
        if (course.sessions.isEmpty()) {
            System.out.println("No sessions found for this course.");
            return;
        }
        for (Session s : course.sessions) {
            System.out.println("Session: " + s.sessionId + ", Date: " + s.date);
            for (AttendanceRecord ar : s.attendanceRecords) {
                System.out.printf("Student: %s, Status: %s, Remarks: %s%n",
                        ar.student.name, ar.status, ar.remarks != null ? ar.remarks : "None");
            }
        }
    }

    static void modifyAttendance(User teacher) {
        System.out.println("Enter Course ID: ");
        final String courseId = scanner.nextLine().trim();
        Course course = courses.stream()
                .filter(c -> c.courseId.equals(courseId) && (c.teacher != null && c.teacher.equals(teacher)))
                .findFirst()
                .orElse(null);
        if (course == null) {
            System.out.println("Invalid Course ID or you are not assigned to this course.");
            return;
        }
        System.out.println("Enter Session ID: ");
        final String sessionId = scanner.nextLine().trim();
        Session session = course.sessions.stream()
                .filter(s -> s.sessionId.equals(sessionId))
                .findFirst()
                .orElse(null);
        if (session == null) {
            System.out.println("Invalid Session ID.");
            return;
        }
        System.out.println("Enter Student ID: ");
        final String studentId = scanner.nextLine().trim();
        AttendanceRecord record = session.attendanceRecords.stream()
                .filter(ar -> ar.student.id.equals(studentId))
                .findFirst()
                .orElse(null);
        if (record == null) {
            System.out.println("No attendance record found for this student.");
            return;
        }
        System.out.println("Current Status: " + record.status);
        System.out.println("Enter New Status (PRESENT/ABSENT/LATE/EXCUSED): ");
        try {
            record.status = AttendanceStatus.valueOf(scanner.nextLine().trim().toUpperCase());
            System.out.println("Enter New Remarks (or leave blank): ");
            String remarks = scanner.nextLine().trim();
            if (!remarks.isEmpty()) record.remarks = remarks;
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid status entered.");
        }
    }

    static void generateReport(User teacher) {
        System.out.println("Enter Course ID: ");
        final String courseId = scanner.nextLine().trim();
        Course course = courses.stream()
                .filter(c -> c.courseId.equals(courseId) && (c.teacher != null && c.teacher.equals(teacher)))
                .findFirst()
                .orElse(null);
        if (course == null) {
            System.out.println("Invalid Course ID or you are not assigned to this course.");
            return;
        }
        System.out.println("Enter Start Date (YYYY-MM-DD): ");
        LocalDate start;
        try {
            start = LocalDate.parse(scanner.nextLine().trim());
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format. Please use YYYY-MM-DD.");
            return;
        }
        System.out.println("Enter End Date (YYYY-MM-DD): ");
        LocalDate end;
        try {
            end = LocalDate.parse(scanner.nextLine().trim());
            if (end.isBefore(start)) {
                System.out.println("End date must be after start date.");
                return;
            }
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format. Please use YYYY-MM-DD.");
            return;
        }
        for (Student s : course.students) {
            int total = 0, present = 0;
            for (Session ses : course.sessions) {
                if (!ses.date.isBefore(start) && !ses.date.isAfter(end)) {
                    total++;
                    for (AttendanceRecord ar : ses.attendanceRecords) {
                        if (ar.student.equals(s) && ar.status == AttendanceStatus.PRESENT) {
                            present++;
                        }
                    }
                }
            }
            double percentage = total > 0 ? (present * 100.0 / total) : 0;
            System.out.printf("Student: %s, Attendance: %.2f%% (%d/%d)%n",
                    s.name, percentage, present, total);
        }
    }

    static void sendAlert(User teacher) {
        System.out.println("Enter Course ID: ");
        final String courseId = scanner.nextLine().trim();
        Course course = courses.stream()
                .filter(c -> c.courseId.equals(courseId) && (c.teacher != null && c.teacher.equals(teacher)))
                .findFirst()
                .orElse(null);
        if (course == null) {
            System.out.println("Invalid Course ID or you are not assigned to this course.");
            return;
        }
        for (Student s : course.students) {
            int total = course.sessions.size();
            int present = 0;
            for (Session ses : course.sessions) {
                for (AttendanceRecord ar : ses.attendanceRecords) {
                    if (ar.student.equals(s) && ar.status == AttendanceStatus.PRESENT) {
                        present++;
                    }
                }
            }
            double percentage = total > 0 ? (present * 100.0 / total) : 0;
            if (percentage < minAttendancePercentage) {
                System.out.printf("Alert: %s has low attendance in %s (%.2f%%).%n",
                        s.name, course.courseName, percentage);
            }
        }
    }

    static void requestCorrection(Student student) {
        System.out.println("Enter Session ID: ");
        final String sessionId = scanner.nextLine().trim();
        Session session = findSession(sessionId);
        if (session == null) {
            System.out.println("Invalid Session ID.");
            return;
        }
        System.out.println("Enter Requested Status (PRESENT/ABSENT/LATE/EXCUSED): ");
        try {
            AttendanceStatus status = AttendanceStatus.valueOf(scanner.nextLine().trim().toUpperCase());
            System.out.println("Enter Reason: ");
            String reason = scanner.nextLine().trim();
            requests.add(new Request("R" + (requests.size() + 1), student, session, status, reason));
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid status entered.");
        }
    }

    static void checkAttendanceNotifications(Student student) {
        for (Course c : courses) {
            if (c.students.contains(student)) {
                int totalSessions = c.sessions.size();
                int presentSessions = 0;
                for (Session s : c.sessions) {
                    for (AttendanceRecord ar : s.attendanceRecords) {
                        if (ar.student.equals(student) && ar.status == AttendanceStatus.PRESENT) {
                            presentSessions++;
                        }
                    }
                }
                double attendancePercentage = totalSessions > 0 ? (presentSessions * 100.0 / totalSessions) : 0;
                if (attendancePercentage < minAttendancePercentage) {
                    System.out.printf("Warning: Low attendance in %s (%.2f%%). Minimum required: %.2f%%%n",
                            c.courseName, attendancePercentage, minAttendancePercentage);
                }
            }
        }
    }

    static void viewRequestStatus(Student student) {
        boolean hasRequests = false;
        for (Request r : requests) {
            if (r.student.equals(student)) {
                hasRequests = true;
                System.out.printf("Request %s for Session %s: Status %s, Requested %s, Reason: %s%n",
                        r.requestId, r.session.sessionId, r.status, r.requestedStatus, r.reason);
            }
        }
        if (!hasRequests) {
            System.out.println("No correction requests found.");
        }
    }

    static void updatePersonalInfo(Student student) {
        System.out.println("New Email: ");
        String email = scanner.nextLine().trim();
        if (!email.isEmpty() && email.contains("@")) {
            student.email = email;
        } else if (!email.isEmpty()) {
            System.out.println("Invalid email format. Keeping current email.");
        }
        System.out.println("New Phone: ");
        String phone = scanner.nextLine().trim();
        if (!phone.isEmpty() && phone.matches("\\d+")) {
            student.phone = phone;
        } else if (!phone.isEmpty()) {
            System.out.println("Invalid phone number. Keeping current phone.");
        }
    }

    static void markAttendance(User teacher) {
        System.out.println("Enter Course ID: ");
        final String courseId = scanner.nextLine().trim();
        Course course = courses.stream()
                .filter(c -> c.courseId.equals(courseId) && (c.teacher != null && c.teacher.equals(teacher)))
                .findFirst()
                .orElse(null);
        if (course == null) {
            System.out.println("Invalid Course ID or you are not assigned to this course.");
            return;
        }
        Session session = new Session("S" + (course.sessions.size() + 1), LocalDate.now());
        for (Student s : course.students) {
            System.out.println("Status for " + s.name + " (PRESENT/ABSENT/LATE/EXCUSED): ");
            try {
                AttendanceStatus status = AttendanceStatus.valueOf(scanner.nextLine().trim().toUpperCase());
                AttendanceRecord ar = new AttendanceRecord(s, status);
                if (status == AttendanceStatus.PRESENT || status == AttendanceStatus.LATE) {
                    System.out.println("Enter Check-in Time (HH:MM, or leave blank): ");
                    String checkIn = scanner.nextLine().trim();
                    if (!checkIn.isEmpty()) {
                        try {
                            ar.checkInTime = LocalTime.parse(checkIn);
                        } catch (DateTimeParseException e) {
                            System.out.println("Invalid time format. Skipping check-in time.");
                        }
                    }
                    System.out.println("Enter Check-out Time (HH:MM, or leave blank): ");
                    String checkOut = scanner.nextLine().trim();
                    if (!checkOut.isEmpty()) {
                        try {
                            ar.checkOutTime = LocalTime.parse(checkOut);
                        } catch (DateTimeParseException e) {
                            System.out.println("Invalid time format. Skipping check-out time.");
                        }
                    }
                }
                System.out.println("Enter Remarks (or leave blank): ");
                String remarks = scanner.nextLine().trim();
                if (!remarks.isEmpty()) ar.remarks = remarks;
                session.attendanceRecords.add(ar);
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid status. Skipping student.");
            }
        }
        course.sessions.add(session);
    }

    static void manageUsers() {
        System.out.println("1. Add User\n2. Update User\n3. Delete User");
        try {
            int choice = Integer.parseInt(scanner.nextLine().trim());
            if (choice == 1) {
                System.out.println("Enter Role (student/teacher/admin): ");
                final String role = scanner.nextLine().trim().toLowerCase();
                System.out.println("Enter ID: ");
                final String id = scanner.nextLine().trim();
                if (users.stream().anyMatch(u -> u.id.equals(id))) {
                    System.out.println("ID already exists.");
                    return;
                }
                System.out.println("Enter Name: ");
                final String name = scanner.nextLine().trim();
                System.out.println("Enter Email: ");
                final String email = scanner.nextLine().trim();
                System.out.println("Enter Phone: ");
                final String phone = scanner.nextLine().trim();
                System.out.println("Enter Password: ");
                final String password = scanner.nextLine().trim();
                if (role.equals("student")) {
                    System.out.println("Enter Class Section: ");
                    final String classSection = scanner.nextLine().trim();
                    users.add(new Student(id, name, email, phone, password, classSection));
                } else if (role.equals("teacher")) {
                    users.add(new Teacher(id, name, email, phone, password));
                } else if (role.equals("admin")) {
                    users.add(new Administrator(id, name, email, phone, password));
                } else {
                    System.out.println("Invalid role entered.");
                    return;
                }
                System.out.println("User added successfully.");
            } else if (choice == 2) {
                System.out.println("Enter User ID: ");
                final String id = scanner.nextLine().trim();
                User user = users.stream()
                        .filter(u -> u.id.equals(id))
                        .findFirst()
                        .orElse(null);
                if (user == null) {
                    System.out.println("User not found.");
                    return;
                }
                System.out.println("New Email: ");
                String email = scanner.nextLine().trim();
                if (!email.isEmpty() && email.contains("@")) {
                    user.email = email;
                }
                System.out.println("New Phone: ");
                String phone = scanner.nextLine().trim();
                if (!phone.isEmpty() && phone.matches("\\d+")) {
                    user.phone = phone;
                }
                System.out.println("New Password: ");
                String password = scanner.nextLine().trim();
                if (!password.isEmpty()) {
                    user.password = password;
                }
                System.out.println("User updated successfully.");
            } else if (choice == 3) {
                System.out.println("Enter User ID: ");
                final String id = scanner.nextLine().trim();
                User user = users.stream()
                        .filter(u -> u.id.equals(id))
                        .findFirst()
                        .orElse(null);
                if (user != null) {
                    users.remove(user);
                    System.out.println("User deleted successfully.");
                } else {
                    System.out.println("User not found.");
                }
            } else {
                System.out.println("Invalid option.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: Please enter a numeric value.");
        }
    }

    static void manageCourses() {
        System.out.println("1. Add Course\n2. Update Course\n3. Delete Course");
        try {
            int choice = Integer.parseInt(scanner.nextLine().trim());
            if (choice == 1) {
                System.out.println("Enter Course ID: ");
                final String courseId = scanner.nextLine().trim();
                if (courses.stream().anyMatch(c -> c.courseId.equals(courseId))) {
                    System.out.println("Course ID already exists.");
                    return;
                }
                System.out.println("Enter Course Name: ");
                final String courseName = scanner.nextLine().trim();
                if (courseName.isEmpty()) {
                    System.out.println("Course name cannot be empty.");
                    return;
                }
                System.out.println("Enter Teacher ID (or leave blank for none): ");
                final String teacherId = scanner.nextLine().trim();
                Teacher teacher = null;
                if (!teacherId.isEmpty()) {
                    teacher = (Teacher) users.stream()
                            .filter(u -> u instanceof Teacher && u.id.equals(teacherId))
                            .findFirst()
                            .orElse(null);
                    if (teacher == null) {
                        System.out.println("Teacher not found.");
                        return;
                    }
                }
                Course course = new Course(courseId, courseName, teacher);
                System.out.println("Enter Student IDs to enroll (comma-separated, or leave blank): ");
                final String studentIdsInput = scanner.nextLine().trim();
                if (!studentIdsInput.isEmpty()) {
                    String[] studentIds = studentIdsInput.split(",");
                    for (String sid : studentIds) {
                        sid = sid.trim();
                        final String finalSid = sid;
                        Student student = (Student) users.stream()
                                .filter(u -> u instanceof Student && u.id.equals(finalSid))
                                .findFirst()
                                .orElse(null);
                        if (student != null) {
                            course.students.add(student);
                        } else {
                            System.out.println("Student " + finalSid + " not found. Skipping.");
                        }
                    }
                }
                courses.add(course);
                System.out.println("Course added successfully.");
            } else if (choice == 2) {
                System.out.println("Enter Course ID: ");
                final String courseId = scanner.nextLine().trim();
                Course course = courses.stream()
                        .filter(c -> c.courseId.equals(courseId))
                        .findFirst()
                        .orElse(null);
                if (course == null) {
                    System.out.println("Course not found.");
                    return;
                }
                System.out.println("Enter New Course Name (or leave blank to keep current): ");
                String courseName = scanner.nextLine().trim();
                if (!courseName.isEmpty()) {
                    course.courseName = courseName;
                }
                System.out.println("Enter New Teacher ID (or leave blank to keep current): ");
                final String teacherId = scanner.nextLine().trim();
                if (!teacherId.isEmpty()) {
                    Teacher teacher = (Teacher) users.stream()
                            .filter(u -> u instanceof Teacher && u.id.equals(teacherId))
                            .findFirst()
                            .orElse(null);
                    if (teacher == null) {
                        System.out.println("Teacher not found. Keeping current teacher.");
                    } else {
                        course.teacher = teacher;
                    }
                }
                System.out.println("Update Student Enrollment? (yes/no): ");
                final String updateEnrollment = scanner.nextLine().trim();
                if (updateEnrollment.equalsIgnoreCase("yes")) {
                    course.students.clear();
                    System.out.println("Enter Student IDs to enroll (comma-separated, or leave blank): ");
                    final String studentIdsInput = scanner.nextLine().trim();
                    if (!studentIdsInput.isEmpty()) {
                        String[] studentIds = studentIdsInput.split(",");
                        for (String sid : studentIds) {
                            sid = sid.trim();
                            final String finalSid = sid;
                            Student student = (Student) users.stream()
                                    .filter(u -> u instanceof Student && u.id.equals(finalSid))
                                    .findFirst()
                                    .orElse(null);
                            if (student != null) {
                                course.students.add(student);
                            } else {
                                System.out.println("Student " + finalSid + " not found. Skipping.");
                            }
                        }
                    }
                }
                System.out.println("Course updated successfully.");
            } else if (choice == 3) {
                System.out.println("Enter Course ID: ");
                final String courseId = scanner.nextLine().trim();
                Course course = courses.stream()
                        .filter(c -> c.courseId.equals(courseId))
                        .findFirst()
                        .orElse(null);
                if (course != null) {
                    courses.remove(course);
                    System.out.println("Course deleted successfully.");
                } else {
                    System.out.println("Course not found.");
                }
            } else {
                System.out.println("Invalid option.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: Please enter a numeric value.");
        }
    }

    static void viewAnalytics() {
        if (courses.isEmpty()) {
            System.out.println("No courses available.");
            return;
        }
        for (Course c : courses) {
            int totalSessions = c.sessions.size();
            int totalPresent = 0;
            for (Session s : c.sessions) {
                for (AttendanceRecord ar : s.attendanceRecords) {
                    if (ar.status == AttendanceStatus.PRESENT) {
                        totalPresent++;
                    }
                }
            }
            double avgAttendance = totalSessions > 0 ? (totalPresent * 100.0 / (totalSessions * c.students.size())) : 0;
            System.out.printf("Course: %s, Total Sessions: %d, Average Attendance: %.2f%%\n",
                    c.courseName, totalSessions, avgAttendance);
        }
    }

    static void configureRules() {
        System.out.println("Enter Minimum Attendance Percentage: ");
        try {
            double percentage = Double.parseDouble(scanner.nextLine().trim());
            if (percentage >= 0 && percentage <= 100) {
                minAttendancePercentage = percentage;
                System.out.println("Minimum attendance set to " + percentage + "%.");
            } else {
                System.out.println("Percentage must be between 0 and 100.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid number format.");
        }
    }

    static void handleRequests() {
        if (requests.isEmpty()) {
            System.out.println("No requests available.");
            return;
        }
        for (Request r : requests) {
            if (r.status == RequestStatus.PENDING) {
                System.out.printf("Request %s: Student %s, Session %s, Requested %s, Reason: %s\n",
                        r.requestId, r.student.name, r.session.sessionId, r.requestedStatus, r.reason);
                System.out.println("Approve? (yes/no): ");
                final String approval = scanner.nextLine().trim();
                if (approval.equalsIgnoreCase("yes")) {
                    r.status = RequestStatus.APPROVED;
                    for (Course c : courses) {
                        for (Session s : c.sessions) {
                            if (s.sessionId.equals(r.session.sessionId)) {
                                for (AttendanceRecord ar : s.attendanceRecords) {
                                    if (ar.student.equals(r.student)) {
                                        ar.status = r.requestedStatus;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    r.status = RequestStatus.DENIED;
                }
            }
        }
    }

    static void viewRegisteredStudents(User user) {
        List<Student> studentsToDisplay;
        if (user instanceof Administrator) {
            studentsToDisplay = users.stream()
                    .filter(u -> u instanceof Student)
                    .map(u -> (Student) u)
                    .toList();
        } else if (user instanceof Teacher) {
            Teacher teacher = (Teacher) user;
            studentsToDisplay = courses.stream()
                    .filter(c -> c.teacher != null && c.teacher.equals(teacher))
                    .flatMap(c -> c.students.stream())
                    .distinct()
                    .toList();
        } else {
            System.out.println("Unauthorized access.");
            return;
        }

        if (studentsToDisplay.isEmpty()) {
            System.out.println("No registered students found.");
            return;
        }

        System.out.println("\nRegistered Students:");
        for (Student s : studentsToDisplay) {
            System.out.printf("Student ID: %s, Name: %s, Class Section: %s%n", s.id, s.name, s.classSection);
            List<Course> studentCourses = courses.stream()
                    .filter(c -> c.students.contains(s))
                    .toList();
            if (studentCourses.isEmpty()) {
                System.out.println("  Registered Courses: None");
                System.out.println("  Assigned Teachers: None");
            } else {
                System.out.println("  Registered Courses:");
                for (Course c : studentCourses) {
                    System.out.printf("    - %s (%s)%n", c.courseName, c.courseId);
                }
                System.out.println("  Assigned Teachers:");
                studentCourses.stream()
                        .filter(c -> c.teacher != null)
                        .map(c -> c.teacher.name)
                        .distinct()
                        .forEach(teacherName -> System.out.printf("    - %s%n", teacherName));
            }
            System.out.println();
        }
    }

    static Session findSession(String sessionId) {
        for (Course c : courses) {
            for (Session s : c.sessions) {
                if (s.sessionId.equals(sessionId)) {
                    return s;
                }
            }
        }
        return null;
    }
}