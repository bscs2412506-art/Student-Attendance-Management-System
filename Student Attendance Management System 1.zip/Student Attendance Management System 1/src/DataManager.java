import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class DataManager {
    private static final String DB_URL = "jdbc:sqlite:StudentAttendance.db";

    // Initialize database and create tables if they don't exist
    public static void initializeDatabase() throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            Statement stmt = conn.createStatement();
            // Create users table
            stmt.execute("CREATE TABLE IF NOT EXISTS users (" +
                    "type TEXT, id TEXT PRIMARY KEY, name TEXT, email TEXT, phone TEXT, password TEXT, classSection TEXT)");
            // Create courses table
            stmt.execute("CREATE TABLE IF NOT EXISTS courses (" +
                    "courseId TEXT PRIMARY KEY, courseName TEXT, teacherId TEXT)");
            // Create course_students table (for many-to-many relationship)
            stmt.execute("CREATE TABLE IF NOT EXISTS course_students (" +
                    "courseId TEXT, studentId TEXT, PRIMARY KEY (courseId, studentId))");
            // Create sessions table
            stmt.execute("CREATE TABLE IF NOT EXISTS sessions (" +
                    "sessionId TEXT PRIMARY KEY, courseId TEXT, date TEXT)");
            // Create attendance table
            stmt.execute("CREATE TABLE IF NOT EXISTS attendance (" +
                    "sessionId TEXT, studentId TEXT, status TEXT, checkInTime TEXT, checkOutTime TEXT, remarks TEXT)");
            // Create requests table
            stmt.execute("CREATE TABLE IF NOT EXISTS requests (" +
                    "requestId TEXT PRIMARY KEY, studentId TEXT, sessionId TEXT, requestedStatus TEXT, reason TEXT, status TEXT)");
        }
    }

    static List<User> loadUsers() throws SQLException {
        List<User> users = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM users")) {
            while (rs.next()) {
                String type = rs.getString("type");
                String id = rs.getString("id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String phone = rs.getString("phone");
                String password = rs.getString("password");
                if (type.equals("student")) {
                    String classSection = rs.getString("classSection");
                    users.add(new Student(id, name, email, phone, password, classSection));
                } else if (type.equals("teacher")) {
                    users.add(new Teacher(id, name, email, phone, password));
                } else if (type.equals("admin")) {
                    users.add(new Administrator(id, name, email, phone, password));
                }
            }
        }
        return users;
    }

    static List<Course> loadCourses(List<User> users) throws SQLException {
        List<Course> courses = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM courses")) {
            while (rs.next()) {
                String courseId = rs.getString("courseId");
                String courseName = rs.getString("courseName");
                String teacherId = rs.getString("teacherId");
                User teacher = users.stream()
                        .filter(u -> u.id.equals(teacherId) && u instanceof Teacher)
                        .findFirst().orElse(null);
                if (teacher == null) continue;
                Course course = new Course(courseId, courseName, teacher);
                // Load students for this course
                try (PreparedStatement pstmt = conn.prepareStatement(
                        "SELECT studentId FROM course_students WHERE courseId = ?")) {
                    pstmt.setString(1, courseId);
                    ResultSet rsStudents = pstmt.executeQuery();
                    while (rsStudents.next()) {
                        String studentId = rsStudents.getString("studentId");
                        User student = users.stream()
                                .filter(u -> u.id.equals(studentId) && u instanceof Student)
                                .findFirst().orElse(null);
                        if (student != null) {
                            course.students.add((Student) student);
                        }
                    }
                }
                courses.add(course);
            }
        }
        return courses;
    }

    static void loadSessions(List<Course> courses) throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM sessions")) {
            while (rs.next()) {
                String courseId = rs.getString("courseId");
                String sessionId = rs.getString("sessionId");
                String dateStr = rs.getString("date");
                Course course = courses.stream()
                        .filter(c -> c.courseId.equals(courseId))
                        .findFirst().orElse(null);
                if (course != null) {
                    try {
                        LocalDate date = LocalDate.parse(dateStr);
                        course.sessions.add(new Session(sessionId, date));
                    } catch (Exception e) {
                    }
                }
            }
        }
    }

    static void loadAttendance(List<Course> courses, List<User> users) throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM attendance")) {
            while (rs.next()) {
                String sessionId = rs.getString("sessionId");
                String studentId = rs.getString("studentId");
                String statusStr = rs.getString("status");
                String checkIn = rs.getString("checkInTime");
                String checkOut = rs.getString("checkOutTime");
                String remarks = rs.getString("remarks");
                Student student = (Student) users.stream()
                        .filter(u -> u.id.equals(studentId) && u instanceof Student)
                        .findFirst().orElse(null);
                if (student == null) continue;
                for (Course c : courses) {
                    for (Session s : c.sessions) {
                        if (s.sessionId.equals(sessionId)) {
                            try {
                                AttendanceRecord ar = new AttendanceRecord(student, AttendanceStatus.valueOf(statusStr.toUpperCase()));
                                if (checkIn != null && !checkIn.isEmpty()) ar.checkInTime = LocalTime.parse(checkIn);
                                if (checkOut != null && !checkOut.isEmpty()) ar.checkOutTime = LocalTime.parse(checkOut);
                                if (remarks != null && !remarks.isEmpty()) ar.remarks = remarks;
                                s.attendanceRecords.add(ar);
                            } catch (IllegalArgumentException e) {
                            }
                        }
                    }
                }
            }
        }
    }

    static List<Request> loadRequests(List<User> users, List<Course> courses) throws SQLException {
        List<Request> requests = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM requests")) {
            while (rs.next()) {
                String requestId = rs.getString("requestId");
                String studentId = rs.getString("studentId");
                String sessionId = rs.getString("sessionId");
                String requestedStatus = rs.getString("requestedStatus");
                String reason = rs.getString("reason");
                String status = rs.getString("status");
                Student student = (Student) users.stream()
                        .filter(u -> u.id.equals(studentId) && u instanceof Student)
                        .findFirst().orElse(null);
                if (student == null) continue;
                Session session = null;
                for (Course c : courses) {
                    for (Session s : c.sessions) {
                        if (s.sessionId.equals(sessionId)) {
                            session = s;
                            break;
                        }
                    }
                    if (session != null) break;
                }
                if (session == null) continue;
                try {
                    Request request = new Request(requestId, student, session, AttendanceStatus.valueOf(requestedStatus.toUpperCase()), reason);
                    request.status = RequestStatus.valueOf(status.toUpperCase());
                    requests.add(request);
                } catch (IllegalArgumentException e) {
                }
            }
        }
        return requests;
    }

    static void saveUsers(List<User> users) throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT OR REPLACE INTO users (type, id, name, email, phone, password, classSection) VALUES (?, ?, ?, ?, ?, ?, ?)")) {
            for (User u : users) {
                pstmt.setString(1, u instanceof Student ? "student" : u instanceof Teacher ? "teacher" : "admin");
                pstmt.setString(2, u.id);
                pstmt.setString(3, u.name);
                pstmt.setString(4, u.email);
                pstmt.setString(5, u.phone);
                pstmt.setString(6, u.password);
                pstmt.setString(7, u instanceof Student ? ((Student) u).classSection : null);
                pstmt.executeUpdate();
            }
        }
    }

    static void saveCourses(List<Course> courses) throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            PreparedStatement pstmtCourse = conn.prepareStatement(
                    "INSERT OR REPLACE INTO courses (courseId, courseName, teacherId) VALUES (?, ?, ?)");
            PreparedStatement pstmtStudent = conn.prepareStatement(
                    "INSERT OR REPLACE INTO course_students (courseId, studentId) VALUES (?, ?)");
            // Clear existing course_students
            conn.createStatement().execute("DELETE FROM course_students");
            for (Course c : courses) {
                pstmtCourse.setString(1, c.courseId);
                pstmtCourse.setString(2, c.courseName);
                pstmtCourse.setString(3, c.teacher != null ? c.teacher.id : "");
                pstmtCourse.executeUpdate();
                for (Student s : c.students) {
                    pstmtStudent.setString(1, c.courseId);
                    pstmtStudent.setString(2, s.id);
                    pstmtStudent.executeUpdate();
                }
            }
        }
    }

    static void saveSessions(List<Course> courses) throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT OR REPLACE INTO sessions (sessionId, courseId, date) VALUES (?, ?, ?)")) {
            for (Course c : courses) {
                for (Session s : c.sessions) {
                    pstmt.setString(1, s.sessionId);
                    pstmt.setString(2, c.courseId);
                    pstmt.setString(3, s.date.toString());
                    pstmt.executeUpdate();
                }
            }
        }
    }

    static void saveAttendance(List<Course> courses) throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT OR REPLACE INTO attendance (sessionId, studentId, status, checkInTime, checkOutTime, remarks) VALUES (?, ?, ?, ?, ?, ?)")) {
            for (Course c : courses) {
                for (Session s : c.sessions) {
                    for (AttendanceRecord ar : s.attendanceRecords) {
                        pstmt.setString(1, s.sessionId);
                        pstmt.setString(2, ar.student.id);
                        pstmt.setString(3, ar.status.toString());
                        pstmt.setString(4, ar.checkInTime != null ? ar.checkInTime.toString() : null);
                        pstmt.setString(5, ar.checkOutTime != null ? ar.checkOutTime.toString() : null);
                        pstmt.setString(6, ar.remarks);
                        pstmt.executeUpdate();
                    }
                }
            }
        }
    }

    static void saveRequests(List<Request> requests) throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT OR REPLACE INTO requests (requestId, studentId, sessionId, requestedStatus, reason, status) VALUES (?, ?, ?, ?, ?, ?)")) {
            for (Request r : requests) {
                pstmt.setString(1, r.requestId);
                pstmt.setString(2, r.student.id);
                pstmt.setString(3, r.session.sessionId);
                pstmt.setString(4, r.requestedStatus.toString());
                pstmt.setString(5, r.reason);
                pstmt.setString(6, r.status.toString());
                pstmt.executeUpdate();
            }
        }
    }
}