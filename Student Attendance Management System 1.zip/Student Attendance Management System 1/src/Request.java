class Request {
    String requestId;
    Student student;
    Session session;
    AttendanceStatus requestedStatus;
    String reason;
    RequestStatus status;

    Request(String requestId, Student student, Session session, AttendanceStatus requestedStatus, String reason) {
        this.requestId = requestId;
        this.student = student;
        this.session = session;
        this.requestedStatus = requestedStatus;
        this.reason = reason;
        this.status = RequestStatus.PENDING;
    }

    Request(String requestId, Student student, Session session, AttendanceStatus requestedStatus, String reason, RequestStatus status) {
        this.requestId = requestId;
        this.student = student;
        this.session = session;
        this.requestedStatus = requestedStatus;
        this.reason = reason;
        this.status = status;
    }
}